import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class UserThread implements Runnable{
    private final Socket socket;
    private final int number;
    private PrintWriter printWriter;

    UserThread(int number, Socket socket){
        this.socket = socket;
        this.number = number;
        try {
            printWriter = new PrintWriter(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        System.out.println(name+"执行了任务..." + number);
//            System.out.println(executorService);//输出线程池状态

        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String string;
            while ((string = bufferedReader.readLine()) != null){
                System.out.println(number+" " + string);//输出客户端信息内容
                string = string.substring(7);
                break;
            }

            printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println("Client " + number + " for " + string);
            printWriter.flush();

            while ((string = bufferedReader.readLine()) != null){
                if (string.equals("OK")){
                    bufferedReader.close();
                    printWriter.close();
                    socket.close();

                    for(int i = 0; i < 10; i++){
                        if(number == Client.N * i){
                            final double end = System.currentTimeMillis();

//                            System.out.println("开始：" + Client.startTime);
                            System.out.println("开始" + Server.start);
                            System.out.println("结束" + end);
//                            t = end- Client.startTime;
                            double t = (end - Server.start)/1000;
                            String tt = String.format("%.3f", t);
                            System.out.println("计时:" + tt + "秒");

                            System.out.println(name.substring(14));
                        }
                    }
                    break;
                }
            }
            Thread.sleep(100);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
}