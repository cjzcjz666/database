import java.io.*;
import java.net.Socket;
import java.util.concurrent.CountDownLatch;

public class MyRunnable implements Runnable {

    private final CountDownLatch start;

    MyRunnable(CountDownLatch start){
        this.start = start;
    }

    @Override
    public void run() {
        String string = "Access " + randomLetter();
        try {
            start.await();
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        post(string);
    }

    private synchronized void post(String string) {
        Socket socket = null;
        while (socket == null) {
            try {
                socket = new Socket("127.0.0.1",33333);
            } catch (IOException e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        }

        try {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println(string);
            printWriter.flush();

            String echo;
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            while ((echo = bufferedReader.readLine())!=null){
                System.out.println(echo);
                printWriter.println("OK");
                printWriter.flush();
                break;
            }
            bufferedReader.close();
            printWriter.close();


        } catch (Exception e){
            post(string);
        } finally {
            try {
                socket.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String randomLetter(){
        String letter = "";
        letter = letter + (char)(Math.random()*26+'A');
        return letter;
    }
}
