import java.util.concurrent.CountDownLatch;

public class Client {
    public static int N = 1000;
    public static long startTime;

    public static void main(String[] args) throws InterruptedException{

        CountDownLatch start = new CountDownLatch(1);
        System.out.println("等待其他线程完成");
        for (int i = 0; i < N; i++) {
            new Thread(new MyRunnable(start)).start();
        }
        System.out.println("创建线程完成");
        startTime = System.currentTimeMillis();
        System.out.println("开始" + startTime);
        start.countDown();
    }
}
