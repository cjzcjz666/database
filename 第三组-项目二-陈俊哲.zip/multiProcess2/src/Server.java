import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.*;

public class Server {
    private static ExecutorService executorService;
    public static double start;
    public static int poolSize = 100;

    public static void main(String[] args) {
        int number = 0;

        try {
            ServerSocket serverSocket = new ServerSocket(33333);
            System.out.println("***服务器即将启动，等待客户端链接***");
//            System.out.println(Runtime.getRuntime().availableProcessors());  16
//            executorService = Executors.newFixedThreadPool(poolSize);
            executorService = Executors.newCachedThreadPool();
//            ThreadPoolExecutor pool = new ThreadPoolExecutor(10,10,5, TimeUnit.SECONDS, new LinkedBlockingDeque<Runnable>());

            while (true){
                Socket socket = serverSocket.accept();
                number++;
                UserThread user = new UserThread(number,socket);

                for(int i = 0; i < 10; i++){
                    if(number == 1 + i * Client.N){
                        start = System.currentTimeMillis();
//                    t1 = user.currentTime();
                        System.out.println("开始" + start);
                    }
                }
                executorService.submit(user);
            }
        }catch (Exception e){
            System.out.println(number);
            e.printStackTrace();
        }
    }


}
