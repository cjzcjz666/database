package com.iodine.clac;

import com.iodine.common.util.StringUtil;

public class Praser {
    private Token m_crtToken;
    private char[] m_Text;
    private int m_Index;

    public ASTNode DoPrase() throws ParserException {
        GetNextToken();
        return Expression();
    }

    /*
    private ASTNode Expression() throws ParserException{
        ASTNode tnode = Term();
        ASTNode e1node = Expression1();

        return new ASTNode(ASTNode.ASTNodeType.OperatorPlus, tnode, e1node);
    }

    private ASTNode Expression1() throws ParserException {
        ASTNode tnode;
        ASTNode e1node;

        switch(m_crtToken.type) {
            case Plus:
                GetNextToken();
                tnode = Term();
                e1node = Expression1();
                return new ASTNode(ASTNode.ASTNodeType.OperatorPlus, e1node, tnode);
            case Minus:
                GetNextToken();
                tnode = Term();
                e1node = Expression1();
                return new ASTNode(ASTNode.ASTNodeType.OperatorMinus, e1node, tnode);
        }
        return new ASTNode(0);
    }
     */
    private ASTNode Expression() throws ParserException {return Expression(null);}
    private ASTNode Expression(ASTNode fnode) throws ParserException{
        if(fnode == null){
            return  Expression(Term());
        }
        ASTNode nextTerm;
        switch(m_crtToken.type) {
            case Plus:
                GetNextToken();
                nextTerm = Term();
                return Expression(new ASTNode(ASTNode.ASTNodeType.OperatorPlus, fnode, nextTerm));
            case Minus:
                GetNextToken();
                nextTerm = Term();
                return Expression(new ASTNode(ASTNode.ASTNodeType.OperatorMinus, fnode, nextTerm));
        }
        return fnode;
    }

    /*
    ASTNode Term() throws ParserException {
        ASTNode fnode = Factor();
        ASTNode t1node = Term1();

        return new ASTNode(ASTNode.ASTNodeType.OperatorMul, fnode, t1node);
    }

    ASTNode Term1() throws ParserException{
        ASTNode fnode;
        ASTNode t1node;

        switch(m_crtToken.type) {
            case Mul:
                GetNextToken();
                fnode = Factor();
                t1node = Term1();
                return new ASTNode(ASTNode.ASTNodeType.OperatorMul, t1node, fnode);

            case Div:
                GetNextToken();
                fnode = Factor();
                t1node = Term1();
                return new ASTNode(ASTNode.ASTNodeType.OperatorDiv, t1node, fnode);

            case Power10:
                GetNextToken();
                fnode = Factor();
                t1node = Term1();
                return new ASTNode(ASTNode.ASTNodeType.OperatorPower10, t1node, fnode);

        }
        return new ASTNode(1);
    }
     */
    ASTNode Term() throws ParserException {return Term(null);}
    ASTNode Term(ASTNode fnode) throws ParserException {
        if(fnode == null){
            return Term(Factor());
        }
        ASTNode nextFactor;
        switch(m_crtToken.type) {
            case Mul:
                GetNextToken();
                nextFactor = Factor();
                return Term(new ASTNode(ASTNode.ASTNodeType.OperatorMul, fnode, nextFactor));
            case Div:
                GetNextToken();
                nextFactor = Factor();
                return Term(new ASTNode(ASTNode.ASTNodeType.OperatorDiv, fnode, nextFactor));
            case Power10:
                GetNextToken();
                nextFactor = Factor();
                return Term(new ASTNode(ASTNode.ASTNodeType.OperatorPower10, fnode, nextFactor));
        }
        return fnode;
    }

    //根据已经匹配到的符号，返回一个Node, 并解析下一个token.
    ASTNode Factor() throws ParserException {
        ASTNode node;
        switch(m_crtToken.type) {
            case OpenParenthesis:
                GetNextToken();
                node = Expression();
                Match(')');
                return node;
            case Sin:
                GetNextToken();
                node = Factor();
                return new ASTNode(ASTNode.ASTNodeType.UnarySin,node);
            case Cos:
                GetNextToken();
                node = Factor();
                return new ASTNode(ASTNode.ASTNodeType.UnaryCos,node);
            case Minus:
                GetNextToken();
                node = Factor();
                return new ASTNode(ASTNode.ASTNodeType.UnaryMinus,node);
            case Number:
                double value = m_crtToken.value;
                GetNextToken();
                return new ASTNode(value);
            default:
                throw new ParserException("Unexpected token '" + m_crtToken.type.enumField + "' at position " + m_Index, m_Index);
        }
    }

    //断言下个字符是 ')' 并解析下一个token.
    void Match(char expected) throws ParserException {
        if(m_Text[m_Index-1] == expected) {
            GetNextToken();
        } else {
            throw new ParserException("Expected token '" + expected + "' at position " + m_Index, m_Index);
        }
    }

    //后移游标跳空格
    void SkipWhitespaces()  {
        while(StringUtil.isEmptyChar(m_Text[m_Index])) m_Index++;
    }

    //取合法Token 放入 m_crtToken 中 并后移游标
    void GetNextToken() throws ParserException {
        SkipWhitespaces();

        m_crtToken.value = 0;
        // m_crtToken.symbol = 0;

        if(m_Text[m_Index] == 0) {
            m_crtToken.type = Token.TokenType.EndOfText;
            return;
        }

        if(StringUtil.isDigit(m_Text[m_Index])) {
            m_crtToken.type = Token.TokenType.Number;
            m_crtToken.value = GetNumber();
            return;
        }

        m_crtToken.type = Token.TokenType.Error;

        for (Token.TokenType token : Token.TokenType.values()) {
            String mark = token.enumField;
            if(mark.equals("")) continue;

            boolean fail = false;
            for(int p = 0 ; p < mark.length(); p++){
                if(m_Text[m_Index + p] != mark.charAt(p)){
                    fail = true;
                    break;
                }
            }

            if(!fail){
                m_crtToken.type = token;
                m_Index += mark.length();
                break;
            }
        }

        if(m_crtToken.type == Token.TokenType.Error){
            throw new ParserException("Unexpected token '" + m_Text[m_Index] + "' at position " + m_Index, m_Index);
        }

    }

    //取合法数字放入 m_crtToken 中 并后移游标
    double GetNumber() throws ParserException {
        SkipWhitespaces();

        String tmpStr = "";
        while(StringUtil.isDigit(m_Text[m_Index])) {tmpStr += m_Text[m_Index]; m_Index++;}
        if(m_Text[m_Index] == '.') {tmpStr += m_Text[m_Index]; m_Index++;}
        while(StringUtil.isDigit(m_Text[m_Index])) {tmpStr += m_Text[m_Index]; m_Index++;}
        if(tmpStr.equals(""))
            throw new ParserException("Number expected but not found!", m_Index);

        return Double.valueOf(tmpStr);
    }

    public Praser(String content) {
        m_crtToken = new Token();
        m_Text = new char[content.length()+1];
        for(int i=0;i<content.length();i++){
            m_Text[i] = content.charAt(i);
        }
        m_Text[content.length()] = 0;
        m_Index = 0;
    }
}
