package com.iodine.clac;

public class EvaluatorException extends Exception {
    public EvaluatorException() {
        super();
    }
    public EvaluatorException(String msg) {
        super(msg);
    }
}
