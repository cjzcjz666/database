package com.iodine.clac;

public class Calculator {

    public double work(String content) throws ParserException,EvaluatorException {
        ASTTree astTree = new ASTTree(content);
        return astTree.getValue();
    }

}
