package com.iodine.clac;

public class Evaluator {
    double EvaluateSubtree(ASTNode ast) throws EvaluatorException {
        if(ast == null)
            throw new EvaluatorException("Incorrect abstract syntax tree");

        if(ast.type == ASTNode.ASTNodeType.NumberValue)
            return ast.value;
        else if(ast.type == ASTNode.ASTNodeType.UnaryMinus)
            return -EvaluateSubtree(ast.left);
        else if(ast.type == ASTNode.ASTNodeType.UnarySin)
            return Math.sin(EvaluateSubtree(ast.left) * Math.acos(-1) / 180);
        else if(ast.type == ASTNode.ASTNodeType.UnaryCos)
            return Math.cos(EvaluateSubtree(ast.left) * Math.acos(-1) / 180);
        else {
            double v1 = EvaluateSubtree(ast.left);
            double v2 = EvaluateSubtree(ast.right);
            switch(ast.type) {
                case OperatorPlus:  return v1 + v2;
                case OperatorMinus: return v1 - v2;
                case OperatorMul:   return v1 * v2;
                case OperatorDiv:   return v1 / v2;
                case OperatorPower10:   return v1 * Math.pow(10,v2);
            }
        }

        throw new EvaluatorException("Incorrect syntax tree!");
    }

    public double DoEvaluate(ASTTree ast) throws EvaluatorException {
        if(ast == null)
            throw new EvaluatorException("Incorrect abstract syntax tree");

        return EvaluateSubtree(ast.root);
    }
}
