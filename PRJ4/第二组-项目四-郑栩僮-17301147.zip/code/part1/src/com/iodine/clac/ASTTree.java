package com.iodine.clac;

public class ASTTree {
    public ASTNode root;

    public ASTTree(ASTNode root){
        this.root = root;
    }

    public ASTTree(String content) throws ParserException{
        Praser praser = new Praser(content);
        this.root = praser.DoPrase();
    }

    public double getValue() throws EvaluatorException{
        Evaluator evaluator = new Evaluator();
        return evaluator.DoEvaluate(this);
    }

}
