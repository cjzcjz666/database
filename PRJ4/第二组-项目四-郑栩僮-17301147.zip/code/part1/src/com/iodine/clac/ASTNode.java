package com.iodine.clac;

public class ASTNode {

    public ASTNodeType type;
    public double value;
    public ASTNode left;
    public ASTNode right;

    ASTNode() {
        this(ASTNodeType.Undefined, null, null);
    }

    ASTNode(ASTNodeType type, ASTNode left){
        this(type, left, null);
    }

    ASTNode(ASTNodeType type, ASTNode left, ASTNode right) {
        this.type = type;
        this.left = left;
        this.right = right;
    }

    ASTNode(double value){
        this.type = ASTNodeType.NumberValue;
        this.value = value;
    }

    public static enum ASTNodeType {
        Undefined,
        OperatorPlus,
        OperatorMinus,
        OperatorMul,
        OperatorDiv,
        OperatorPower10,
        UnaryMinus,
        NumberValue,
        UnarySin,
        UnaryCos,
    };
}
