package com.iodine.clac;

public class ParserException extends Exception {
    private int value;
    public ParserException() {
        super();
    }
    public ParserException(String msg, int value) {
        super(msg);
        this.value = value;
    }
    public int getValue() {
        return value;
    }
}
