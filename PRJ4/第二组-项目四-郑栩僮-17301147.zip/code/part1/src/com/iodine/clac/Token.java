package com.iodine.clac;

public class Token {

    public TokenType type;
    public double value;
    //public char	symbol;

    public Token() {}

    public Token(TokenType type, double value, char symbol){
        this.type = type;
        this.value = value;
        //this.symbol = symbol;
    }

    public static enum TokenType {
        Error(""),
        EndOfText(""),
        Number(""),
        Power10("e"),
        Plus("+"),
        Minus("-"),
        Mul("*"),
        Div("/"),
        Sin("sin"),
        Cos("cos"),
        OpenParenthesis("("),
        ClosedParenthesis(")");

        public String enumField;
        // 构造方法
        private TokenType(String name) {
            this.enumField = name;
        }

    };

}
