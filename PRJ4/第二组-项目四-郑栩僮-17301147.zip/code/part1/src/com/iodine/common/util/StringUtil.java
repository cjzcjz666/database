package com.iodine.common.util;

public class StringUtil {
    public static boolean isEmptyChar (char c){
        return (c == ' ' || c == '\t' || c == '\n' || c == '\f' || c == '\r');
    }
    public static boolean isDigit(char c){
        return (c >= '0' && c <= '9');
    }
}
