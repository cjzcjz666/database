package com.iodine;

import com.iodine.clac.Calculator;
import com.iodine.clac.EvaluatorException;
import com.iodine.clac.ParserException;

import java.util.Scanner;

public class Test {

    private static void singleTest(String content){
        try {
            System.out.println("calculate: " + content);

            Calculator calculator = new Calculator();
            double value = calculator.work(content);

            System.out.println("\t  " + value);

        } catch (EvaluatorException evaE) {
            System.out.println("\t  EvaluatorException: " + evaE.getMessage());
        } catch (ParserException parE) {
            System.out.println("\t  ParserException: " + parE.getMessage());
        }
    }

    public static void main(String[] args) {

        singleTest("1+2+3+4");
        singleTest("1*2*3*4");
        singleTest("1-2-3-4");
        singleTest("1/2/3/4");
        singleTest("1*2+3*4");
        singleTest("1+2*3+4");
        singleTest("(1+2)*(3+4)");
        singleTest("1+(2*3)*(4+5)");
        singleTest("1+(2*3)/4+5");
        singleTest("5/(4+3)/2");
        singleTest("1 + 2.5");
        singleTest("125");
        singleTest("-1");
        singleTest("-1+(-2)");
        singleTest("-1+(-2.0)");

        singleTest("sin(30)");
        singleTest("cos(90)");
        singleTest("1*2.5e2");


        singleTest("10 ** 3");
        singleTest("   1*2,5");
        singleTest("M1 + 2.5");
        singleTest("1 + 2&5");
        singleTest("1 * 2.5.6");
        singleTest("*1 / 2.5");

        Scanner sc = new Scanner(System.in);
        String line = "";
        while( (line = sc.nextLine()) != null ){
            singleTest(line);
        }


    }
}
