import java_cup.runtime.Symbol;
import javacup.*;
import javaflex.*;

import java.io.FileReader;

public class Test {
    public static void main(String argv[]) throws Exception {

        FileReader fr = new FileReader(argv[0]);
        JavaFlexScanner scanner = new JavaFlexScanner(fr);

        JavaCUPParser parser = new JavaCUPParser(scanner);
        parser.parse();

    }
}
