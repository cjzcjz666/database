// EvalExpression.cpp : Defines the entry point for the console application.
//

#include "pch.h"
#include "Parser.h"
#include "Evaluator.h"
#include <iostream>

void Test(const char* text)
{
   Parser parser;

   try 
   {
      ASTNode* ast = parser.Parse(text);

      try 
      {
         Evaluator eval;
         double val = eval.Evaluate(ast);

         std::cout << text << " = " << val << std::endl;
      }
      catch(EvaluatorException& ex)
      {
		  std::cout << text << " \t " << ex.what() << std::endl; 
      }

      delete ast;
   }
   catch(ParserException& ex)
   {
      std::cout << text << " \t " << ex.what() << std::endl; 
   }   
}

int _tmain(int argc, _TCHAR* argv[])
{
   Test("sin30*3.14/180");
   Test("1+sin(30*3.14/180)+10*4");
   Test("1+sin(30*3.14/180)+3*");
   Test("tan(-1+3)");
   Test("cos(tan(sin1))");
   Test("5+cos1-5*4");
   return 0;
}

