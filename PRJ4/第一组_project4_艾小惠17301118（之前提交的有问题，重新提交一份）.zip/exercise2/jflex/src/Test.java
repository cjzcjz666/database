import java_cup.runtime.*;
import java.io.*;
import java.util.Scanner;

class Test {
    public static void main(String args[]) throws Exception {

        ComplexSymbolFactory csf = new ComplexSymbolFactory();
            try {
                System.out.println("Input statement:");
                BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
                String str = "";
                String read = "";
                read = bf.readLine()+" ";
                while (!read.equals(" ")) {
                    str += read;
                    read = bf.readLine()+" ";
                }
                System.out.println("Input:" + str);
                bf.close();
                ScannerBuffer lexer = new ScannerBuffer(
                        new Lexer(
                                new BufferedReader(new StringReader(str)), csf));
                Parser p = new Parser(lexer, csf);
                p.parse();
            }catch (Exception e){
                System.out.println("Error！！");
            }




    }
}
