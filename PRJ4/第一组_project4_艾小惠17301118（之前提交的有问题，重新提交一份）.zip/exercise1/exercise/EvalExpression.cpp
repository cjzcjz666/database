// EvalExpression.cpp : Defines the entry point for the console application.
//

#include "pch.h"
#include "Parser.h"
#include "Evaluator.h"
#include <iostream>

void Test(const char* text)
{
   Parser parser;

   try 
   {
      ASTNode* ast = parser.Parse(text);

      try 
      {
         Evaluator eval;
         double val = eval.Evaluate(ast);

         std::cout << text << " = " << val << std::endl;
      }
      catch(EvaluatorException& ex)
      {
		  std::cout << text << " \t " << ex.what() << std::endl; 
      }

      delete ast;
   }
   catch(ParserException& ex)
   {
      std::cout << text << " \t " << ex.what() << std::endl; 
   }   
}

int _tmain(int argc, _TCHAR* argv[])
{
   Test("sin3");
   return 0;
}

