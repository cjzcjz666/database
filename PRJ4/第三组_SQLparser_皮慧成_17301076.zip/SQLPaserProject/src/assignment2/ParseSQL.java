package assignment2;
import java_cup.runtime.ComplexSymbolFactory;
import java_cup.runtime.ScannerBuffer;
import java_cup.runtime.XMLElement;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import java.io.*;

public class ParseSQL {
    public static void main(String[] argv){
        String st="F:\\SQLPaserProject\\src\\assignment2\\test.txt";
        try {
            ComplexSymbolFactory csf = new ComplexSymbolFactory();
            Reader reader=new FileReader(new File(st));
            scanner sc=new scanner(reader,csf);
            ScannerBuffer lexer = new ScannerBuffer(sc);
            Parser p=new Parser(lexer,csf);

            //p.parse();
            Object op=p.parse().value;
            System.out.println(op.toString());
            XMLElement e = (XMLElement)op;
            // create XML output file
            XMLOutputFactory outFactory = XMLOutputFactory.newInstance();
            XMLStreamWriter sw = outFactory.createXMLStreamWriter(new FileOutputStream("temp.xml"  ));
            XMLElement.dump(lexer,sw,e,"swf");
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.setOutputProperty(OutputKeys.INDENT, "yes");
            xformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            Source text = new StreamSource("temp.xml");
            xformer.transform(text, new StreamResult(new File("output.xml")));
            System.out.println("finish");
        }
        catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
