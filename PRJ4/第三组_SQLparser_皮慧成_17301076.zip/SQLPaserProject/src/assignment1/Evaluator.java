package assignment1;


import static assignment1.ASTNodeType.*;

public class Evaluator {

    private double EvaluateSubtree(ASTNode ast) throws EvaluatorException
    {
        if(ast == null)
            throw new EvaluatorException("Incorrect syntax tree!");

        if(ast.Type == NumberValue)
            return ast.Value;
        else if(ast.Type == UnaryMinus)
            return -EvaluateSubtree(ast.Left);
        else if (ast.Type==OperatorSin)
            return Math.sin(EvaluateSubtree(ast.Right));
        else if (ast.Type==OperatorCos)
            return Math.cos(EvaluateSubtree(ast.Right));
        else
        {
            double v1 = EvaluateSubtree(ast.Left);
            double v2 = EvaluateSubtree(ast.Right);
            switch(ast.Type)
            {
                case OperatorPlus:  return v1 + v2;
                case OperatorMinus: return v1 - v2;
                case OperatorMul:   return v1 * v2;
                case OperatorDiv:   return v1 / v2;
            }
        }

        throw new EvaluatorException("Incorrect syntax tree!");
    }

    public double Evaluate(ASTNode ast) throws EvaluatorException
    {
        if(ast == null)
            throw new EvaluatorException("Incorrect abstract syntax tree");

        return EvaluateSubtree(ast);
    }
}
