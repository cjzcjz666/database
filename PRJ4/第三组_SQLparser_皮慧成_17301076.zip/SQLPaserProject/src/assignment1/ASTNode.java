package assignment1;
import java.util.*;
import static assignment1.ASTNodeType.*;

public class ASTNode {

    public double Value;
    public ASTNodeType Type;
    public ASTNode Left;
    public ASTNode Right;

    public ASTNode(){
        Type= Undefined;
        Value=0;
        Left= null;
        Right=null;
    }


}
