package assignment1;

public class ParserException extends Exception{
    int position;

    public ParserException(String msg,int pos)
    {
        super(msg);
        position=pos;
    }
}
