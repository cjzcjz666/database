package assignment1;

public enum ASTNodeType {
    Undefined,
    OperatorPlus,
    OperatorMinus,
    OperatorMul,
    OperatorDiv,
    OperatorSin,
    OperatorCos,
    UnaryMinus,
    NumberValue
}
