package assignment1;

import static assignment1.ASTNodeType.*;
import static assignment1.MyTokenType.*;

public class Parser {
    private MyToken m_crtToken=new MyToken();
    private char[] m_Text;
    private int  m_Index=0;

    private ASTNode Expression() throws ParserException
    {
        ASTNode tnode=Term();
        ASTNode e1node=Expression1();

        return CreateNode(OperatorPlus, tnode, e1node);
    }

    private ASTNode Expression1() throws ParserException
    {
        ASTNode tnode;
        ASTNode e1node;

        switch(m_crtToken.Type)
        {
            case Plus:
                GetNextToken();
                tnode = Term();
                e1node=Expression1();

                return CreateNode(OperatorPlus, e1node, tnode);

            case Minus:
                GetNextToken();
                tnode=Term();
                e1node=Expression1();

                return CreateNode(OperatorMinus, e1node, tnode);
        }

        return CreateNodeNumber(0);
    }

    private ASTNode Term() throws ParserException
    {
        ASTNode fnode=Factor();

        ASTNode t1node=Term1();

        return CreateNode(OperatorMul, fnode, t1node);
    }

    private ASTNode Term1() throws ParserException
    {
        ASTNode fnode=null;
        ASTNode t1node;

        switch(m_crtToken.Type)
        {
            case Mul:
                GetNextToken();
                fnode=Factor();

                t1node=Term1();
                return CreateNode(OperatorMul, t1node, fnode);

            case Div:
                GetNextToken();
                fnode=Factor();

                t1node=Term1();
                return CreateNode(OperatorDiv, t1node, fnode);

        }

        return CreateNodeNumber(1);
    }

    private ASTNode Factor() throws ParserException
    {
        ASTNode node;
        switch(m_crtToken.Type)
        {
            case OpenParenthesis:
                GetNextToken();
                node=Expression();
                Match(')');
                return node;

            case Minus:
                GetNextToken();
                node=Factor();
                return CreateUnaryNode(node);

            case Number:
            {
                double value = m_crtToken.Value;
                GetNextToken();
                return CreateNodeNumber(value);
            }

            case Sin:
                GetNextToken();
                node=Factor();
                return CreateSinNode(node);

            case Cos:
                GetNextToken();
                node=Factor();
                return CreateCosNode(node);

            default:
            {
                String sstr= "Unexpected token '" + m_crtToken.Symbol + "' at position " + m_Index;
                throw new ParserException(sstr,m_Index);
            }
        }
    }

    private ASTNode CreateNode(ASTNodeType type, ASTNode left, ASTNode right)
    {
        ASTNode node = new ASTNode();
        node.Type = type;
        node.Left=left;
        node.Right=right;

        return node;
    }

    private ASTNode CreateUnaryNode(ASTNode left)
    {
        ASTNode node = new ASTNode();
        node.Type = UnaryMinus;
        node.Left=left;
        node.Right = null;

        return node;
    }

    private ASTNode CreateSinNode(ASTNode right)
    {
        ASTNode node = new ASTNode();
        node.Type = OperatorSin;
        node.Left=null;
        node.Right = right;

        return node;
    }

    private ASTNode CreateCosNode(ASTNode right)
    {
        ASTNode node = new ASTNode();
        node.Type = OperatorCos;
        node.Left=null;
        node.Right = right;

        return node;
    }

    private ASTNode CreateNodeNumber(double value)
    {
        ASTNode node = new ASTNode();
        node.Type = NumberValue;
        node.Value = value;

        return node;
    }

   private void Match(char expected) throws ParserException
    {
        if(m_Text[m_Index-1] == expected)
            GetNextToken();
        else
        {
            String sstr="Expected token '"+ expected + "' at position " + m_Index;
            throw new ParserException(sstr, m_Index);
        }
    }

    private void SkipWhitespaces()
    {
        while(isspace(m_Text[m_Index]))
            m_Index++;
    }

    private void GetNextToken() throws ParserException
    {

        SkipWhitespaces();
        m_crtToken.Value = 0;
        m_crtToken.Symbol = 0;

        if(m_Text[m_Index] == 0)
        {
            m_crtToken.Type = EndOfText;
            return;
        }

        if(isdigit(m_Text[m_Index]))
        {
            m_crtToken.Type = Number;
            m_crtToken.Value = GetNumber();
            return;
        }

        if (m_Text[m_Index]=='s'&&m_Text[m_Index+1]=='i'&&m_Text[m_Index+2]=='n')
        {
            m_crtToken.Type=Sin;
            m_Index+=3;
            return;
        }

        if (m_Text[m_Index]=='c'&&m_Text[m_Index+1]=='o'&&m_Text[m_Index+2]=='s')
        {
            m_crtToken.Type=Cos;
            m_Index+=3;
            return;
        }

        m_crtToken.Type = Error;

        switch(m_Text[m_Index])
        {
            case '+': m_crtToken.Type = Plus; break;
            case '-': m_crtToken.Type = Minus; break;
            case '*': m_crtToken.Type = Mul; break;
            case '/': m_crtToken.Type = Div; break;
            case '(': m_crtToken.Type = OpenParenthesis; break;
            case ')': m_crtToken.Type = ClosedParenthesis; break;
        }

        if(m_crtToken.Type != Error)
        {
            m_crtToken.Symbol = m_Text[m_Index];
            m_Index++;
        }
        else
        {
            String sstr="Unexpected token '" + m_Text[m_Index] + "' at position " + m_Index;
            throw new ParserException(sstr, m_Index);
        }
    }

    private double GetNumber() throws ParserException
    {
        SkipWhitespaces();

        int index = m_Index;

        if (m_Text[m_Index]!='\0')
        {
            while(isdigit(m_Text[m_Index])) m_Index++;
            if(m_Text[m_Index] == '.') m_Index++;
            while(isdigit(m_Text[m_Index])) m_Index++;

        }

        if(m_Index - index == 0)
            throw new ParserException("Number expected but not found!", m_Index);

        StringBuilder sb = new StringBuilder();

        for (int i=index;i<m_Index;i++)
        {
            sb.append(m_Text[i]);
        }

        return Double.parseDouble(sb.toString());
    }

    private boolean isspace(char s)
    {
        return s == ' ';
    }

    private boolean isdigit(char s)
    {
        return Character.isDigit(s);
    }

    public ASTNode Parse(char[] text) throws ParserException
    {
        m_Text = text;
        m_Index = 0;

        GetNextToken();

        return Expression();
    }

}
