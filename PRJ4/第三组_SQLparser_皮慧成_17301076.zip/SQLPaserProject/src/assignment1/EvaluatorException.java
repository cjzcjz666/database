package assignment1;

public class EvaluatorException extends Exception {
    public EvaluatorException(String msg)
    {
        super(msg);
    }
}
