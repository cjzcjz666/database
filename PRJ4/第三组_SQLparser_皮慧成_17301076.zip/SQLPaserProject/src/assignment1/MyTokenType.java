package assignment1;

public enum MyTokenType {
    Error,
    Plus,
    Mul,
    Minus,
    Div,
    Sin,
    Cos,
    EndOfText,
    OpenParenthesis,
    ClosedParenthesis,
    Number
}
