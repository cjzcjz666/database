package assignment1;

import static assignment1.MyTokenType.*;

public class MyToken {
    MyTokenType Type;
    double Value;
    char Symbol;

    public MyToken(){
        Type=Error;
        Value=0;
        Symbol=0;
    }
}
