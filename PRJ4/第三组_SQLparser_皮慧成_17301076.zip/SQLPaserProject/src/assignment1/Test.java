package assignment1;

public class Test {

    static void test(char[] text)
    {
        Parser parser=new Parser();
        try {
            ASTNode ast=parser.Parse(text);
            try
            {
                Evaluator eval=new Evaluator();
                double val=eval.Evaluate(ast);
                System.out.print(text);
                System.out.print("="+val);
                System.out.println();
            }
            catch (EvaluatorException ep)
            {
                System.out.println(ep.getMessage());
            }
        }
        catch (ParserException ex)
        {
            System.out.println(ex.getMessage());
        }

    }

    public static void main(String[] args)
    {
        String st1="1+-2+3*4 \0";
        test(st1.toCharArray());

        String st2="1+sin(30*3.14/180)+10* \0";
        test(st2.toCharArray());

        String st3="1+cos(3+sin0)+3*4 \0";
        test(st3.toCharArray());

        String st4="1+cos+3*4 \0";
        test(st4.toCharArray());

        String st5="1+cos0+3*4 \0";
        test(st5.toCharArray());

        String st6="1+-cos0+3*4 \0";
        test(st6.toCharArray());

        String st7="1+cos(sin0)+3*4 \0";
        test(st7.toCharArray());
    }
}
