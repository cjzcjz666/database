package Client;

public class ClientTest {
    public static void main(String[] args) {
        new ClientsMgr(1000);
    }
}
