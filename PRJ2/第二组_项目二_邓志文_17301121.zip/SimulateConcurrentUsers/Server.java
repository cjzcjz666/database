import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    private static ExecutorService executorService;
    public static void main(String[] args) {
        int number = 0;
        try {
            ServerSocket serverSocket = new ServerSocket(33333);
            System.out.println("***服务器即将启动，等待客户端链接***");
            executorService = Executors.newCachedThreadPool();
            while (true){
                Socket socket = serverSocket.accept();
                number++;
                executorService.submit(new UserThread(number,socket));
//                if (number==1000){
//                    break;
//                }
//                System.out.println(number);
            }
        }catch (Exception e){
            System.out.println(number);
            e.printStackTrace();
        }
//        try{
//            Thread.sleep(60000);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//        System.out.println(" ss" + executorService);

    }

    static class UserThread implements Runnable{
        private Socket socket;
        private int number;
        private PrintWriter printWriter;
        UserThread(int number,Socket socket){
            this.socket = socket;
            this.number = number;
            try {
                printWriter = new PrintWriter(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
//            System.out.println(executorService);//输出线程池状态

            try {
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String string;
                while ((string = bufferedReader.readLine()) != null){
                    System.out.println(number+" " + string);//输出客户端信息内容
                    string = string.substring(7);
                    break;
                }

                printWriter = new PrintWriter(socket.getOutputStream());
                printWriter.println("Client " + number + " for " + string);
                printWriter.flush();

                while ((string = bufferedReader.readLine()) != null){
                    if (string.equals("OK")){
//                        System.out.println("ok");
                        bufferedReader.close();
                        printWriter.close();
                        socket.close();
                        break;
                    }
                }

            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
