import java.util.concurrent.CountDownLatch;

public class Client {
    public static void main(String[] args) throws InterruptedException{
        final int N = 1000;
        CountDownLatch start = new CountDownLatch(1);
//        CountDownLatch done = new CountDownLatch(N);
        System.out.println("等待其他线程完成");
        for (int i = 0; i < N; i++) {
            new Thread(new MyRunnable(start)).start();
        }
        System.out.println("创建线程完成");
        start.countDown();
//        done.await();
    }

}
